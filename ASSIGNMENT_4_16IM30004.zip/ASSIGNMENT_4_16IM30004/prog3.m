clc;
clear all;
%{
-----------------------------------------------------------------------------
NAME    : C.PAVAN KALYAN
ROLL NO : 16IM30004
-----------------------------------------------------------------------------
--------Manufacturing Plant Problem
--------Decision variables

xij= space required in ith month to jth month where i=starting month upto j month's rent for (i,j=1,2,3)

------objective function

 Min z=28000(x11+x21+x31)+45000(x12+x22)+60000(x13)

--- constraints

 x11+x12+x13>=25
 x12+x13+x21+x22>=10
 x13+x22+x31>=20
 xij>=0

%}

f=[28000;45000;60000;28000;45000;28000];
A=[-1,-1,-1,0,0,0;
    0,-1,-1,-1,-1,0;
    0,0,-1,0,-1,-1];
b=[-25;-10;-20];
intcon=[1:6];
lb=[0;0;0;0;0;0;];
[x,fval]=intlinprog(f,intcon,A,b,[],[],lb);
fprintf('The total cost of renting(per 1000m^3) is :%d\n',fval);
for i = 1:3 
    
    fprintf('The amount of land(in 1000m^3) to be rented in month 1 for %d month is:%d \n',i,x(i));
end

 

fprintf('The amount of land(in 1000m^3) to be rented in month 2 for 1 month is:%d\n',x(4));
fprintf('The amount of land(in 1000m^3) to be rented in month 2 for 2 months is:%d\n',x(5));
fprintf('The amount of land(in 1000m^3) to be rented in month 3 for 1 month is:%d\n',x(6));


%{

SOLUTION OBTAINED :

The total cost of renting(per 1000m^3) is :1300000

The amount of land(in 1000m^3) to be rented in month 1 for 1 month is:15 
The amount of land(in 1000m^3) to be rented in month 1 for 2 month is:0 
The amount of land(in 1000m^3) to be rented in month 1 for 3 month is:10 
The amount of land(in 1000m^3) to be rented in month 2 for 1 month is:0
The amount of land(in 1000m^3) to be rented in month 2 for 2 months is:0
The amount of land(in 1000m^3) to be rented in month 3 for 1 month is:10

%}
    




