clc;
clear all;

%{
-----------------------------------------------------------------------------
NAME    : C.PAVAN KALYAN
ROLL NO : 16IM30004
-----------------------------------------------------------------------------

---------------Manufacturing Warehouse Problem
--------------Decision variables

--xij=no of products transported from plant i to distribution centre j for i=1,2,3 and j=1,2,3,4

--Objective function
    
z=min 300x11+200x12+700x13+.........+500x34

-------------Supply constraints

--x11+x12+x13+x14<=5000 
--x21+x22+x23+x24<=6000 
--x31+x32+x33+x34<=2500 

-----------------Demand constraints

--x11+x21+x31=6000 
--x12+x22+x32=4000 
--x13+x23+x33=2000 
--x14+x24+x34=1500 
---xij>=0 for i,j

---------------------------------------------------------------------------
%}
    
    

obj = [300;200;700;600;700;500;200;300;200;500;400;500];

a = [1,1,1,1,0,0,0,0,0,0,0,0;
     0,0,0,0,1,1,1,1,0,0,0,0;
     0,0,0,0,0,0,0,0,1,1,1,1];
 aeq =[1,0,0,0,1,0,0,0,1,0,0,0;
     0,1,0,0,0,1,0,0,0,1,0,0;
     0,0,1,0,0,0,1,0,0,0,1,0;
     0,0,0,1,0,0,0,1,0,0,0,1];
 b = [5000;6000;2500];
 beq = [6000;4000;2000;1500];
 lb = [0;0;0;0;0;0;0;0;0;0;0;0];
 
 
 [x,fval] = linprog(obj,a,b,aeq,beq,lb)
 fprintf('the optimum value for cost is %d \n', fval);
 for i= 1:4
     if x(i) > 1
         fprintf(' The allocation from P1 to D%d is : %d \n',i, x(i));
     end
 end
 j=1;
 for i= 5:8
     if x(i) > 1
         fprintf(' The allocation from P2 to D%d is : %d \n',j, x(i));
         
     end
     j=j+1;
 end
 j=1;
 for i= 9:12
     if x(i) > 1
         fprintf(' The allocation from P3 to D%d is : %d \n',j, x(i));
         
     end
     j=j+1;
 end
 fprintf('Rest all zero')
 
 %{
 
 SOLUTION OBTAINED :
 
 the optimum value for cost is 3950000
 
 The allocation from P1 to D1 is : 3500 
 The allocation from P1 to D2 is : 1500 
 The allocation from P2 to D2 is : 2500 
 The allocation from P2 to D3 is : 2000 
 The allocation from P2 to D4 is : 1500 
 The allocation from P3 to D1 is : 2500 
 
 %}
 
 
 
 


    