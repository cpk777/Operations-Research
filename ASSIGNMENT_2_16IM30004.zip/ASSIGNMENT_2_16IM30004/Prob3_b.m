%Name : Pavan kalyan
%Roll no:16IM30004
% --- ------ Vehicle Problem --------
%---  Decision Variables --------------
% xij is corresponding to i th item put in vehicle j where i =1,2,3,4,5,6,7 and j=1,2,3
% -------- Constraints -----
% ------------ Volume Constraints ---------
% .55x11 + .6x21 + .7x31 + .75x41 + .85x51 + .9x61 + .95x71 <= 3.6 (for vehicle 1)
% .55x12 + .6x22 + .7x32 + .75x42 + .85x52 + .9x62 + .95x72 <= 3.6 (for vehicle 2)
% .55x13 + .6x23 + .7x33 + .75x43 + .85x53 + .9x63 + .95x73 <= 3.6 (for vehicle 3)
% -------- Number of units Constraints ---------
% x11 + x12 + x13 = 2 (for item 1)
% x21 + x22 + x23 = 2 (for item 2)
% x31 + x32 + x33 = 2  (for item 3)
% x41 + x42 + x43 = 2   (for item 4)
% x51 + x52 + x53 = 2    (for item 5)
% x61 + x62 + x63 = 2    (for item 6)
% x71 + x72 + x73 = 2   (for item 7)





F = [ -250; -300; -500; -700; -750; -900; -950; -250; -300; -500; -700; -750; -900; -950; -250; -300; -500; -700; -750; -900; -950];
a = [ 0.55 , 0.6 , 0.7 , 0.75 , 0.85 , 0.9 , 0.9, 0,0,0,0,0,0,0,  0,0,0,0,0,0,0 ;
      0,0,0,0,0,0,0,  0.55 , 0.6 , 0.7 , 0.75 , 0.85 , 0.9 , 0.9,  0,0,0,0,0,0,0;
      0,0,0,0,0,0,0,   0,0,0,0,0,0,0,   0.55 , 0.6 , 0.7 , 0.75 , 0.85 , 0.9 , 0.9 ];
beq = [ 1,0,0,0,0,0,0,     1,0,0,0,0,0,0,         1,0,0,0,0,0,0 ;
        0,1,0,0,0,0,0,     0,1,0,0,0,0,0,         0,1,0,0,0,0,0 ;
        0,0,1,0,0,0,0,     0,0,1,0,0,0,0,         0,0,1,0,0,0,0 ;
        0,0,0,1,0,0,0,     0,0,0,1,0,0,0,         0,0,0,1,0,0,0 ;
        0,0,0,0,1,0,0,     0,0,0,0,1,0,0,         0,0,0,0,1,0,0 ;
        0,0,0,0,0,1,0,     0,0,0,0,0,1,0,         0,0,0,0,0,1,0 ;
        0,0,0,0,0,0,1,     0,0,0,0,0,0,1,         0,0,0,0,0,0,1 ;
        1,1,1,1,1,1,1,     1,1,1,1,1,1,1,         1,1,1,1,1,1,1 ];



P = [ 3.6 ; 3.6 ; 3.6 ];
Qeq = [2;2;2;2;2;2;2;14];
lb = [ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
ub = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1];
[x,fval] = intlinprog( F, [1:21] ,a, P , beq, Qeq, lb , ub);
fprintf(' the total net value maximised %d \n', -fval);
fprintf(' \n \n IN FIRST VEHICLE \n \n');
for i=1:7
    fprintf('\n %d of item %d \n ',x(i),i);
end
fprintf(' \n \n IN SECOND VEHICLE \n \n');
j=1;
for i=8:14
    fprintf('\n %d of item %d \n ',x(i),j);
    j=j+1;
end
fprintf(' \n \n IN THIRD VEHICLE \n \n');
j=1;
for i=15:21
    fprintf('\n %d of item %d \n ',x(i),j);
    j=j+1;
end


%{

-------------SOLUTION ------------------------


 the total net value maximised 8700 
 
 
 IN FIRST VEHICLE 
 

 0 of item 1 
 
 0 of item 2 
 
 0 of item 3 
 
 1.000000e+00 of item 4 
 
 1 of item 5 
 
 1 of item 6 
 
 1 of item 7 
  
 
 IN SECOND VEHICLE 
 

 1 of item 1 
 
 1 of item 2 
 
 1 of item 3 
 
 0 of item 4 
 
 1 of item 5 
 
 1 of item 6 
 
 0 of item 7 
  
 
 IN THIRD VEHICLE 
 

 1 of item 1 
 
 1.000000e+00 of item 2 
 
 1 of item 3 
 
 1 of item 4 
 
 0 of item 5 
 
 0 of item 6 
 
 1.000000e+00 of item 7

%}
