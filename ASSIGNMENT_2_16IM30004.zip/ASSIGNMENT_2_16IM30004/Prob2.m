%Name : Pavan kalyan
%Roll no:16IM30004
%--------Network problem------
%---------Decision variables--------
%(xij=No of items transported from node i to node j for the path defined
%            and for the rest xij=0  )
%Decision variables are:x12,x13,x24,x52,x54,x32,x36,x43,x46
%Objective function:z=min(x12+4x13+x24+3x32+x36+x43+x46+x52+3x54)
%---------Supply constraint---------
%----Balanced transportation problem-----------
%--x12+x13=10 (Supply from node 1)
%--x52+x54=15 (Supply from node 5)
%-----------Demand constraint-----------
%--x13+x43-x32-x36=11  (Demand at node 3)
%--x24+x54-x43-x46=10 (Demand at node 4)
%--x36+x46=4  (Demand at node 6)
%-----------Supply and demand constraint for transhipment node--------
%--x12+x32+x52=x24 =>x12+x32+x52-x24=0 (transhipment at node 2)



f =  [ 1 , 1 , 3 , 1 , 3 , 4 , 1 , 1 , 1];

a = [ -1 , -1 , -1 , 1 , 0 , 0 , 0 , 0 , 0;
     1,0,0,0,0,1,0,0,0;
     0,1,0,0,1,0,0,0,0;
     0,0,0,0,0,0,0,-1,-1;
     0,0,1,0,0,-1,-1,0,0;
     0,0,0,-1,-1,0,1,0,0 ];
 b = [0,10,15,-4,-11,-10];
 aeq = [ 1, 1 ,1 ,-1 ,0,0,0,-1,-1];
 beq = [0];
 lb = [0;0;0;0;0;0;0;0;0];
 [x,fval] = intlinprog(f,[1:9],a,b,aeq,beq,lb,[]);
 
 fprintf('The minimum cost is %d \n', fval);
 fprintf('the transport from 1 to 2 is %d \n', x(1));
 fprintf('the transport from 5 to 2 is %d \n', x(2));
 fprintf('the transport from 1 to 3 is %d \n', x(6));
 fprintf('the transport from 3 to 2 is %d \n', x(3));
 fprintf('the transport from 2 to 4 is %d \n', x(4));
 fprintf('the transport from 5 to 4 is %d \n', x(5));
 fprintf('the transport from 4 to 3 is %d \n', x(7));
 fprintf('the transport from 3 to 6 is %d \n', x(8));
 fprintf('the transport from 4 to 6 is %d \n', x(9));
 
 
 
 %{
 -----------SOLUTION---------------
 
 The minimum cost is 61 
the transport from 1 to 2 is 10 
the transport from 5 to 2 is 15 
the transport from 1 to 3 is 0 
the transport from 3 to 2 is 0 
the transport from 2 to 4 is 21 
the transport from 5 to 4 is 0 
the transport from 4 to 3 is 11 
the transport from 3 to 6 is 4 
the transport from 4 to 6 is 0 
 
 %}
 
