%Name : Pavan kalyan
%Roll no : 16IM30004
% -------- TRANSSHIPMENT PROBLEM ---------------------------------%
% Objective function z = min 5X11+6X21+5.5X31+3X12+3.2X22+2.3X32+6.5X13+2.5X23+6.2X33+ %
%                            6Y11+5.5Y21+5.5Y31+4.5Y12+3.2Y22+2.3Y32+5Y13+2.5Y23+6.2Y33+ %
%                            4Y14+4.7Y24+8Y34                          %
% ----------------------------------------------------------------%
% CONSTRAINTS                                              %
% Xij = no. of units going from plant i to warehouse j     %
% Yij = no. of units going from warehouse i to warehouse j %
% ---- X11+X21+X31 >= Y11+Y12+Y13+Y14 %
% ---- X12+X22+X32 >= Y21+Y22+Y23+Y24 %
% ---- X13+X23+X33 >= Y31+Y32+Y33+Y34 %
% ---- Y11+Y21+Y31 >= 50  %
% ---- Y12+Y22+Y32 >= 130 %
% ---- Y13+Y23+Y33 >= 75  %
% ---- Y14+Y24+Y43 >= 90  %
%-----------------------------------------------------------------%

f = [ 5000 ; 3000 ; 6500 ; 6000 ; 3200 ; 2500 ; 5500 ; 2300 ; 6200 ; 6000 ; 4500 ; 5000 ; 4000 ; 5500 ; 3200 ; 2500 ; 4700 ; 5500 ; 2300 ; 6200 ; 8000 ];
a = [ 1 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 , -1 , -1 , -1 , -1 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ;
      0 , 1 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 0 , -1 , -1 , -1 , -1 , 0 , 0 , 0 , 0 ;
      0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , -1 , -1 , -1 , -1 ;
      0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , 0 ;
      0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 ;
      0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 ;
      0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 , 0 , 0 , 0 , 1 ; ];
c = -a ;
b = [ 0 ; 0 ; 0 ; -50 ; -130 ; -75 ; -90 ];
lb = [ 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0; 0 ; 0 ; 0 ; 0 ];
[x, fval ] = intlinprog( f , [ 1:21 ] , c , b , [] , [] , lb , [] )

fprintf( ' the optimum cost for transportation is %d \n ' , fval );
k = 1 ;
for i = 1 : 3
    for j = 1 : 3
       fprintf(' Procurement from P%d to W%d is : %d \n', i, j , x(k));
       k = k+1 ;
    end
end 
for i = 1 : 3
    for j = 1 : 4
        fprintf(' Procurement from W%d to D%d is : %d \n', i, j , x(k));
        k = k+1 ;
    end
end 

%{

-----------SOLUTION---------------

 the optimum cost for transportation is 2004000 
  Procurement from P1 to W1 is : 0 
 Procurement from P1 to W2 is : 0 
 Procurement from P1 to W3 is : 0 
 Procurement from P2 to W1 is : 0 
 Procurement from P2 to W2 is : 0 
 Procurement from P2 to W3 is : 130 
 Procurement from P3 to W1 is : 0 
 Procurement from P3 to W2 is : 215 
 Procurement from P3 to W3 is : 0 
 Procurement from W1 to D1 is : 0 
 Procurement from W1 to D2 is : 0 
 Procurement from W1 to D3 is : 0 
 Procurement from W1 to D4 is : 0 
 Procurement from W2 to D1 is : 50 
 Procurement from W2 to D2 is : 0 
 Procurement from W2 to D3 is : 75 
 Procurement from W2 to D4 is : 90 
 Procurement from W3 to D1 is : 0 
 Procurement from W3 to D2 is : 130 
 Procurement from W3 to D3 is : 0 
 Procurement from W3 to D4 is : 0

%}

