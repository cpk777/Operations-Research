%--- Name: Pavan Kalyan ---%
%--- Roll No.: 16IM30004 ---%
%--------Swimming pool problem----------
%---------Decision variables---------
%--xi=1,if Lifeguard i is selected for the post
%    =0, if lifeguard i is not selected for all i=1,2...7
%--Objective function:z=min(300x1+180x2+210x3+380x4+200x5+220x6+900x7)
%---------Time constraint for each time slot from 1-9--------
%--x1+x2>=1 =>-x1-x2<=-1 (for time slot 1-2 and 2-3)
%--x1>=1 =>-x1<=-1 (for time slot 3-4)
%--x1+x3+x4>=1 =>-x1-x3-x4<=-1 (for time slot 4-5)
%--x3+x4+x6>=1 =>-x3-x4-x6<=-1 (for time slot 5-6)
%--x3+x4+x5+x6>=1 =>-x3-x4-x5-x6<=-1 (for time slot 6-7)
%--x4+x5+x6>=1 =>-x4-x5-x6<=-1 (for time slot 7-8)
%--x4+x5+x7>=1 =>-x4-x5-x7<=-1 (for time slot 8-9)
%--------Integer and no negativity constraint---------
%--xi>=0 and xi<=1 for all i=1,2,...7

c=[300;180;210;380;200;220;900];
A=[-1,-1,0,0,0,0,0;
    -1,0,0,0,0,0,0;
    -1,0,-1,-1,0,0,0;
    0,0,-1,-1,0,-1,0;
    0,0,-1,-1,-1,-1,0;
    0,0,0,-1,-1,-1,0;
    0,0,0,-1,-1,0,-1];
b=[-1;-1;-1;-1;-1;-1;-1];
Aeq=[];
beq=[];
intcon=[1:7];
lb=[0;0;0;0;0;0;0;];
ub=[1;1;1;1;1;1;1;];
[x,fval]=intlinprog(c,intcon,A,b,Aeq,beq,lb,ub);
for i=1:7
    if x(i)==1
        fprintf('Lifeguard %d is selected for the job\n',i);
    else
        fprintf('Lifeguard %d is not selected for the job\n',i);
    end
end
fprintf('The Total Cost of Selection is: %d\n',fval);



%{
SOLUTION :

Lifeguard 1 is selected for the job
Lifeguard 2 is not selected for the job
Lifeguard 3 is not selected for the job
Lifeguard 4 is selected for the job
Lifeguard 5 is not selected for the job
Lifeguard 6 is not selected for the job
Lifeguard 7 is not selected for the job
The Total Cost of Selection is: 680

%}