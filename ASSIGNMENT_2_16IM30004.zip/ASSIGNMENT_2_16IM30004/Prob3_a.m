%Name : Pavan Kalyan
%Roll no-16IM30024
%-------Vehicle and goods problem-------
%-----Decision variables---------
%--xi=1 if item type i is put in the vehicle
%    =0 if item type i is not put in the vehicle for all i=1,2...7
%--Objective function:z=max(250x1+300x2+500x3+700x4+750x5+900x6+950x7)
%                     z=min(-250x1-300x2-500x3-700x4-750x5-900x6-950x7)
%-------Volume constraint-------------
%--0.55x1+0.6x2+0.7x3+0.75x4+0.85x5+0.9x6+0.95x7<=3.6
%----------Integer and non negativity constraint-------
%---xi<=1  and xi>=0 for all i=1,2,3,4,5,6,7
%--xi is an integer for all i=1,2,...7


f = [ -250 ; -300 ; -500 ; -700 ; -750 ; -900 ; -950 ];
a = [ 0.55 , 0.6 , 0.7 , 0.75 , 0.85 , 0.9 , 0.9 ];
b = [3.6];
lb = [ 0 ; 0 ; 0; 0 ; 0 ; 0 ; 0];
ub = [ 1 ; 1 ; 1 ; 1 ; 1 ; 1 ; 1];
[x,fval] = intlinprog(f, [1:7],a,b,[],[],lb,ub);

fprintf(' the total net value maximised %d \n', -fval);
for i = 1:7
    if x(i) == true
        fprintf(' ITEM %d is to be taken \n', i );
    end
end


%{

-----------SOLUTION ----------------

 the total net value maximised 3300 
 ITEM 4 is to be taken 
 ITEM 5 is to be taken 
 ITEM 6 is to be taken 
 ITEM 7 is to be taken 
%}
