%{

Name : Pavan kalyan
Roll no : 16IM30004
--- Employee Problem 
---  Decision Variables 
xi = number of employee hired on day i : xi>=0
Objective function, z = Min x1+x2+x3+x4+x5+x6+x7 
% --- Constraints

---- Days constarints 

x4+x5+x6+x7+x1>=17 day 1
x2+x5+x6+x7+x1>=13 day 2
x2+x3+x6+x7+x1>=15 day 3
x2+x3+x4+x7+x1>=19 day 4
x4+x5+x2+x3+x1>=14 day 5
x4+x5+x6+x2+x1>=16 day 6
x4+x5+x6+x7+x1>=11 day 7


-------------------------------------------------------------------------------------------

%}
f = [1;1;1;1;1;1;1];
 A = [1,0,0,1,1,1,1;
      1,1,0,0,1,1,1;
      1,1,1,0,0,1,1;
      1,1,1,1,0,0,1;
      1,1,1,1,1,0,0;
      0,1,1,1,1,1,0;
      0,0,1,1,1,1,1];
    
    b  = [17;13;15;19;14;16;11];

  lb=[0;0;0;0;0;0;0];
  
[x,fval] = intlinprog(f,1:7,-A,-b,[],[],lb);

fprintf (' Total employees hired are : %f \n',  fval);
for i=1:7
    fprintf(' No.of employess selected on day %d is : %f \n', i, (x(i)));
end

%{
-----answer-----
Total employees hired are : 23.000000 
 No.of employess selected on day 1 is : 0.000000 
 No.of employess selected on day 2 is : 6.000000 
 No.of employess selected on day 3 is : 0.000000 
 No.of employess selected on day 4 is : 6.000000 
 No.of employess selected on day 5 is : 2.000000 
 No.of employess selected on day 6 is : 2.000000 
 No.of employess selected on day 7 is : 7.000000 

%}