%{
NAME : Pavan Kalyan
Roll No : 16IM30004
 Aeroplane Problem
Decision Variables 
xij = number of crates in segment j i,j , i = 1,2,3,4,5 and j=1,2,3 : xij>=0
Objective function, z = Max 50000*x11 + 50000*x12 + 50000*x13 + 60000*x21 + 60000*x22 + 60000*x23+ 90000*x31 + 90000*x32 + 90000*x33 + 40000*x41 + 40000*x42 + 40000*x43 + 30000*x51 + 30000*x52 + 30000*x53
--- Constraints -----

---- Weight constarints   ---

500*x11+1500*x21+2100*x31+600*x41+400*x51<=8000
500*x12+1500*x22+2100*x32+600*x42+400*x52<=20000
500*x13+1500*x23+2100*x33+600*x43+400*x53<=6000


--- Volume constarints 

25*x11+15*x21+13*x31+20*x41+16*x51<=200
25*x12+15*x22+13*x32+20*x42+16*x52<=500
25*x13+15*x23+13*x33+20*x43+16*x53<=300


--- Crate constarints

x11+x12+x13<=12
 x21+x22+x23<=8
 x31+x32+x33<=22
 x41+x42+x43<=15
 x51+x52+x53<=11
---- Balance Constraints  

(500*x11+1500*x21+2100*x31+600*x41+400*x51)+(500*x13+1500*x23+2100*x33+600*x43+400*x53)-(500*x12+1500*x22+2100*x32+600*x42+400*x52)<=0
(500*x12+1500*x22+2100*x32+600*x42+400*x52)-2*(500*x11+1500*x21+2100*x31+600*x41+400*x51)-2*(500*x13+1500*x23+2100*x33+600*x43+400*x53)<=0

-------------------------------------------------------------------------------------------
%}
f = [50000;50000;50000;60000;60000;60000;90000;90000;90000;40000;40000;40000;30000;30000;30000];
 A = [500,0,0,1500,0,0,2100,0,0,600,0,0,400,0,0;
      0,500,0,0,1500,0,0,2100,0,0,600,0,0,400,0;
      0,0,500,0,0,1500,0,0,2100,0,0,600,0,0,400;
      25,0,0,15,0,0,13,0,0,20,0,0,16,0,0;
      0,25,0,0,15,0,0,13,0,0,20,0,0,16,0;
      0,0,25,0,0,15,0,0,13,0,0,20,0,0,16;
      1,1,1,0,0,0,0,0,0,0,0,0,0,0,0;
      0,0,0,1,1,1,0,0,0,0,0,0,0,0,0;
      0,0,0,0,0,0,1,1,1,0,0,0,0,0,0;
      0,0,0,0,0,0,0,0,0,1,1,1,0,0,0;
      0,0,0,0,0,0,0,0,0,0,0,0,1,1,1;
      500,-500,500,1500,-1500,1500,2100,-2100,2100,600,-600,600,400,-400,400;
      -1000,500,-1000,-3000,1500,-3000,-4200,2100,-4200,-1200,600,-1200,-800,400,-800];
    
    b  = [8000; 20000; 6000; 200; 500; 300;12;8;22;15;11;0;0];

  lb=[0;0;0;0;0;0;0;0;0;0;0;0;0;0;0];
  intcon=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
[x,fval] = intlinprog(-f,intcon,A,b,[],[],lb);

fprintf (' Total value is : %f \n',  -fval);
j=65;
for i=1:3:15
    fprintf(' No.of crates of type %c in front segment is : %f \n', j , x(i));
    j=j+1;
end
j=65;
fprintf('\n\n');
for i=2:3:15
    fprintf(' No.of crates of type %c in middle segment is : %f \n', j , x(i));
    j=j+1;
end
j=65;
fprintf('\n\n');
for i=3:3:15
    fprintf(' No.of crates of type %c in back segment is : %f \n', j , x(i));
    j=j+1;
end

%{

------ANSWER

 Total value is : 2130000.000000 
 No.of crates of type A in front segment is : 1.000000 
 No.of crates of type B in front segment is : 0.000000 
 No.of crates of type C in front segment is : 2.000000 
 No.of crates of type D in front segment is : 0.000000 
 No.of crates of type E in front segment is : 8.000000 


 No.of crates of type A in middle segment is : 0.000000 
 No.of crates of type B in middle segment is : 1.000000 
 No.of crates of type C in middle segment is : 4.000000 
 No.of crates of type D in middle segment is : 15.000000 
 No.of crates of type E in middle segment is : 2.000000 


 No.of crates of type A in back segment is : 11.000000 
 No.of crates of type B in back segment is : 0.000000 
 No.of crates of type C in back segment is : 0.000000 
 No.of crates of type D in back segment is : 0.000000 
 No.of crates of type E in back segment is : 1.000000


%}


