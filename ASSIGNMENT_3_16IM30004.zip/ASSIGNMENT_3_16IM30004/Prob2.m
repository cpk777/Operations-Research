%{
Name : Pavan kalyan
Roll no : 16IM30004
--- Manufacturing Problem 
---  Decision Variables
xij = number of products of i produced i=1,2,3 by A,B,C respctively
Objective function, z = Max y
---- Resource constarints   

x1+x2+x3<=2400 

There can be three price levels. minimum loss in care of any price level
is to be ensured

5x1-x2-x3+y <=0;
7x1-6x2-10x3+y<=0;
-13x1+2x2+6x3<=0;

-------------------------------------------------------------------------------------------
%}
f = [0;0;0;-1];
A = [1,1,1,0;
    5,-1,-1,1;
    7,-6,-10,1;
    -13,2,-6,1];
 
b  = [2400;0;0;0];

lb=[0;0;0;0];
  
[x,fval] = intlinprog(f,1:4,A,b,[],[],lb);

fprintf (' Max over all profit is : %f \n',  -fval);
j=65;
for i=1:3
    fprintf(' No.of products of %c is : %f \n', j, x(i));
    j=j+1;
end

%{

----ANSWER
 Max over all profit is : 2400.000000 
 No.of products of A is : 0.000000 
 No.of products of B is : 1500.000000 
 No.of products of C is : 900.000000 

%}