clc;
clear all;

% --- Transportation Problem --- %

% --- Decision Variables --- %
% --- xij is the no. of units transported from plant "i" to warehouse "j"
% for all i = 1,2,3 and j=1,2,3 --- %
% --- yij is the no. of units transported from warehouse "i" to demand
% point "j" for all i=1,2,3 and j=1,2,3,4 --- %
% --- So the decision variables are
% x11,x12,x13,x21,x22,x23,x31,x32,x33,y11,y12..... and they are all integers---- %

% --- Objective function --- %
% --- Min Z = 
% 5000x11 +3000x12+6500x13+6000x21+3200x22+2500x23+5500x31+2300x32+6200x33+6000y11+4500y12+5000y13+4000y14+5500y21+3200y22
% + 2500y23+4700y24+5500y31+2300y32+6200y33+8000y34 --- %

% --- Constraints --- %
% --- Warehouse input >= Warehouse output constraint --- %

% --- x11 + x21 + x31 - y11 - y12- y13-y14 >= 0 --- %
% --- x12 +x22+x32>=y21+y22+y23+y34 --- %
% --- x13+x23+x33>=y31+y32+y33+y34 --- %

% --- Demand meeting consraint --- %
% --- y11+y21+y31 >=50 --- %
% --- y12+y22+y32>=130
% --- y13+y23+y33 >=75
% --- y14+y24+y34>=90 --- %

f = [5000;3000;6500;6000;3200;2500;5500;2300;6200;6000;4500;5000;4000;5500;3200;2500;4700;5500;2300;6200;8000];
intcon = (1:21);
A = [-1,0,0,-1,0,0,-1,0,0,1,1,1,1,0,0,0,0,0,0,0,0;0,-1,0,0,-1,0,0,-1,0,0,0,0,0,1,1,1,1,0,0,0,0;0,0,-1,0,0,-1,0,0,-1,0,0,0,0,0,0,0,0,1,1,1,1;0,0,0,0,0,0,0,0,0,-1,0,0,0,-1,0,0,0,-1,0,0,0;0,0,0,0,0,0,0,0,0,0,-1,0,0,0,-1,0,0,0,-1,0,0;0,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,-1,0,0,0,-1,0;0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,0,-1,0,0,0,-1];
B = [0;0;0;-50;-130;-75;-90];
LB = [0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0];
UB = [inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf;inf];

[x,fval,exitflag] = intlinprog(f,intcon,A,B,[],[],LB,UB);

fprintf (' The exitflag value is : %d \n', exitflag);

fprintf (' Total cost is : %d \n',  fval);

for i=1:21
    fprintf(' Products transferred is %d \n',x(i));
end



