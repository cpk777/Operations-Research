clc;
clear all;
% --- Luggage Problem --- %

% --- Decision Variables --- %

% --- Yi which is 1 if product i is taken and 0 otherwise. i = {a,b,c,d,e,f}
% --- %

% --- Objective Function --- %

% --- Max Z = 60Ya + 70Yb + 40Yc + 70Yd + 16Ye + 100Yf --- %

% --- Constraints --- %

% --- 6Ya + 7Yb + 4Yc + 9Yd + 3Ye + 8Yf <= 20 --- %

% --- Constraint for relation between selection of A and D item --- %

% --- Yd - Ya <= 0 --- %

f = [-60;-70;-40;-70;-16;-100];
A = [6,7,4,9,3,8;-1,0,0,1,0,0];
B = [20;0];

lb = [0;0;0;0;0;0];
ub = [1;1;1;1;1;1];
intcon = (1:6);

[x,fval,exitflag] = intlinprog(f,intcon,A,B,[],[],lb,ub);

fprintf (' The exitflag value is : %d \n', exitflag);

fprintf (' Total Value of Items is : %f \n',  -1*fval);   

for i=1:6
    if(x(i) == 1)
        fprintf(" Product %d is taken \n", i );
    end
end




