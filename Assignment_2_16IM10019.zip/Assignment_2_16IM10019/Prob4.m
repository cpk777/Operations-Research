clc;
clear all;
% --- LifeGuard Problem --- %

% --- Decision Variables --- %

% Ya1,Ya2,Ya3,Ya4,Yb1,Yb2,Yc4,Yc5,Yc6,Yd4,Yd5,Yd6,Yd7,Yd8,Ye6,Ye7,Ye8,Yf5,Yf6,Yf7,Yg8
% where if Ya1 is 1, it indicates that the lifeguard a is present for the slot 1-2 and so on,
% and 0 if he is not present in that slot and all the DV are integers with possible values as 0 or 1 ---- %

% --- Objective function --- %

% --- Minimize Z = 300Ya1 + 180Yb1 + 210Yc4 + 380Yd4 + 200Ye6 + 220Yf5 +
% 900Yg8 --- %

% --- Constraints --- %

% --- Equality of the value of the variables for a particular person --- %

% --- Ya1 - Ya2 = 0  --- %
% --- Ya1 - Ya3 = 0 --- %
% --- Ya1 - Ya4 = 0 --- %
% --- Yb1 - Yb2 = 0 --- %
% --- Yc4 - Yc5 = 0 --- %
% --- Yc4 - Yc6 = 0 --- %
% --- Yd4 - Yd5 = 0 --- %
% --- Yd4 - Yd6 = 0 --- %
% --- Yd4 - Yd7 = 0 --- %
% --- Yd4 - Yd8 = 0 --- %
% --- Ye6 - Ye7 = 0 --- %
% --- Ye6 - Ye8 = 0 --- %
% --- Yf5 - Yf6 = 0 --- %
% --- Yf5 - Yf7 = 0 --- %

% --- Atleast one person at a particular time constraint for each one hour
% slot --- %

% --- Ya1 + Yb1 >= 1 --- %
% --- Ya2 + Yb2 >= 1 --- %
% --- Ya3 >= 1 --- %
% --- Ya4 + Yc4 + Yd4 >= 1 --- %
% --- Yc5 + Yd5 + Yf5 >= 1 --- %
% --- Yc6 + Yd6 + Ye6 + Yf6 >= 1 --- %
% --- Yd7 + Ye7 + Yf7 >= 1 --- %
% --- Yd8 + Ye8 + Yg8 >= 1 --- %

f =[300/4;300/4;300/4;300/4;180/2;180/2;210/3;210/3;210/3;380/5;380/5;380/5;380/5;380/5;200/3;200/3;200/3;220/3;220/3;220/3;900];

% --- f = [300;0;0;0;180;0;210;0;0;380;0;0;0;0;200;0;0;220;0;0;900]; --- %

intcon = (1:21);

Aeq = [1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
    1,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
    1,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
    0,0,0,0,1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
    0,0,0,0,0,0,1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0;
    0,0,0,0,0,0,1,0,-1,0,0,0,0,0,0,0,0,0,0,0,0;
    0,0,0,0,0,0,0,0,0,1,-1,0,0,0,0,0,0,0,0,0,0;
    0,0,0,0,0,0,0,0,0,1,0,-1,0,0,0,0,0,0,0,0,0;
    0,0,0,0,0,0,0,0,0,1,0,0,-1,0,0,0,0,0,0,0,0;
    0,0,0,0,0,0,0,0,0,1,0,0,0,-1,0,0,0,0,0,0,0;
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,-1,0,0,0,0,0;
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,-1,0,0,0,0;
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,-1,0,0;
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,-1,0;    
];

Beq = [0;0;0;0;0;0;0;0;0;0;0;0;0;0];

A = [-1,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
     0,-1,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
     0,0,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;
     0,0,0,-1,0,0,-1,0,0,-1,0,0,0,0,0,0,0,0,0,0,0;
     0,0,0,0,0,0,0,-1,0,0,-1,0,0,0,0,0,0,-1,0,0,0;
     0,0,0,0,0,0,0,0,-1,0,0,-1,0,0,-1,0,0,0,-1,0,0;
     0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,-1,0,0,0,-1,0;
     0,0,0,0,0,0,0,0,0,0,0,0,0,-1,0,0,-1,0,0,0,-1];
 B = [-1;-1;-1;-1;-1;-1;-1;-1];
 
 lb = [0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0;0];
 ub = [1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1;1];
 
 [x,fval,exitflag] = intlinprog(f,intcon,A,B,Aeq,Beq,lb,ub);
 
 fprintf (' The exitflag value is : %d \n', exitflag);

 fprintf (' Total Cost of LifeGuards is : %d \n',  fval);   

    if( x(1) == 1 )
        fprintf(' Lifeguard A is called \n');   
    end
    if( x(5) == 1 )
        fprintf(' Lifeguard B is called \n');   
    end
    if( x(7) == 1 )
        fprintf(' Lifeguard C is called \n');   
    end
    if( x(10) == 1 )
        fprintf(' Lifeguard D is called \n');   
    end
    if( x(15) == 1 )
        fprintf(' Lifeguard E is called \n');   
    end
    if( x(18) == 1 )
        fprintf(' Lifeguard F is called \n');   
    end
    if( x(21) == 1 )
        fprintf(' Lifeguard G is called \n');   
    end
    
























