% --- Netwrok Problem --- %

% --- Decision Variables --- %
% --- xij is the number of units of products that gets transported from NODE i to NODE j --- %
% --- From the arrows in network shown, the required variables are only 
% --- x12,x13,x24,x32,x36,x43,x46,x52,x54 --- %

% --- Objective Function --- %
% --- Min Z = x12+(4)x13+x24+(3)x32+x36+x43+x46+1x52+x54(3) --- %

% --- Constraints --- %
% --- x12 + x13 <= 10
% --- x52 + x54 <= 15
% --- x13 -x32-x36 +x43 >=11 
% --- x24-x43-x46+x54 >= 10
% --- x46 + x36 >= 4 --- %
% --- -x12+x24-x32-x52<=0 --- %

f = [1;4;1;3;1;1;1;1;3];
A = [1,1,0,0,0,0,0,0,0;0,0,0,0,0,0,0,1,1;0,-1,0,1,1,-1,0,0,0;0,0,-1,0,0,1,1,0,-1;0,0,0,0,-1,0,-1,0,0;-1,0,1,-1,0,0,0,-1,0];
B = [10;15;-11;-10;-4;0];
intcon = (1:9);
LB = [0,0,0,0,0,0,0,0,0];
UB = [inf,inf,inf,inf,inf,inf,inf,inf,inf];

[x,fval,exitflag] = intlinprog(f,intcon,A,B,[],[],LB,UB);

fprintf (' The exitflag value is : %d \n', exitflag);

fprintf (' Total cost is : %d \n',  fval);

for i=1:9
    fprintf(' Products transferred is %d \n',x(i));
end


