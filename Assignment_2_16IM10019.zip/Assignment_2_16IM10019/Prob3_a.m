clc;
clear all;
% --- Transportation in truck --- %

% --- Decision variables --- %
% --- yi be binary variables which is 1 if the item i is taken and 0 if
% not. --- %

% --- Objective Function --- %
% --- Max Z = 250y1 + 300y2 + 500y3 + 700y4 + 750y5 + 900y6 + 950y7 --- %

% --- Constraint --- %
% --- 0.55y1 + 0.6y2 + 0.7y3 + 0.75y4 + 0.85y5 + 0.9y6 + 0.95y7 <= 3.6 ---%

f = [-250;-300;-500;-700;-750;-900;-950];
intcon = (1:7);
A = [0.55,0.6,0.7,0.75,0.85,0.9,0.95];
B = 3.6;
lb = [0;0;0;0;0;0;0];
ub = [1;1;1;1;1;1;1];

[x,fval,exitflag] = intlinprog(f,intcon,A,B,[],[],lb,ub);

fprintf (' The exitflag value is : %d \n', exitflag);

fprintf (' Total Value of products is : %d \n',  -1*fval);

for i=1:7
    if(x(i) == 1)
        fprintf(' Product %d is transferred \n',i);
    end    
end



