clc;
clear all;
% --- Luggage Problem --- %

% --- Decision Variables --- %

% --- Yi which is 1 if product i is taken and 0 otherwise. i = {a,b,c,d,e,f}
% --- %

% --- Objective Function --- %

% --- Max Z = -30Ya - 35Yb - 20Yc - 65Yd - 29Ye - 20Yf + 300 --- %

% --- Constraints --- %

% --- -6Ya - 7Yb - 4Yc - 9Yd - 3Ye - 8Yf  <= -20 --- %

% --- Constraint for relation between selection of A and D item --- %

% --- Yd - Ya <= 0 --- %

f = [30;35;20;65;29;20];
A = [-6,-7,-4,-9,-3,-8];
B = [-20];

lb = [0;0;0;0;0;0];
ub = [1;1;1;1;1;1];
intcon = (1:6);

[x,fval,exitflag] = intlinprog(f,intcon,A,B,[],[],lb,ub);

fprintf (' The exitflag value is : %d \n', exitflag);

fprintf (' Total Value of Items is : %f \n',  300-1*fval);   

for i=1:6
    if(x(i) == 1)
        fprintf(" Product %d is taken \n", i );
    end
end




