% -- CRUD CHEMICAL PLANT PROBLEM ---- %
% ---decision variables ------ %
% ----- xi = the amount of chemical sent after an hour for recycling ---%
% ---x1 is amount sent after 9-10 , x2 => amount after 10-11 and vise versa
% --- xi >= 0 ---%
% --- objective function, fval = min 30x1 + 40x2 +35x3 + 45x4 + 38x5 + 50x6
% --CONSTRAINTS -- %
% -- x1 <=300 
 %    x2 <= 240 + (300-x1)|| (300-x1) is the left amount after the 1st hour
 %   x3 <= 600+(240-x2+300-x1) ||(540-(x1+x2) is left amount after the 2hr
 %   x4 <= 200+(600+300+240-(x1+x2+x3))
 %   x5 <= 300+(200+600+240+300-(x1+x2+x3+x4))
 %   x6 = 900+(300+200+600+240+300-(x1+x2+x3+x4+x5) || there shouldn't be
 %                                          any overnight chemical, so.
 
 %---CONSTRAINTS ----%
 % 600+300+240-(x1+x2+x3) <= 1000 || because the left amount of chemical
 %                          can not be greater than 1000, until the first two hours the collective
 %                      production is lessa than 1000, similarly
 % 600+3000+240+200-(x1+x2+x3+x4) <= 1000
 % 300+200+600+240+300-(x1+x2+x3+x4+x5) <=1000
 % after the sixth hour all the chemical is sent away, so no need of this
 % constraint.

 % -----------------------------------------------------------------%

min = [ 30 , 40 , 35 , 45 , 38 , 50 ];
a = [ 1 , 0 , 0 , 0 , 0 , 0 ;
      1 , 1 , 0 , 0 , 0 , 0 ;
      1 , 1 , 1 , 0 , 0 , 0 ;
      1 , 1 , 1 , 1 , 0 , 0 ;
      1 , 1 , 1 , 1 , 1 , 0 ;
     -1 ,-1 ,-1 , 0 , 0 , 0 ;
     -1 ,-1 ,-1 ,-1 , 0 , 0 ;
     -1 ,-1 ,-1 ,-1 ,-1 , 0 ] ;
b = [ 300 ; 540 ; 1140 ; 1340 ; 1640 ; -140 ; -340 ; -640 ] ;
aeq = [ 1 , 1 , 1 , 1 , 1 , 1 ];
beq = [2540] ;
lb = [0;0;0;0;0;0];
[x,fval] = linprog( min , a , b , aeq , beq , lb);
fprintf('The price to recycle is : %d  \n', fval );
for i = 1:6
    fprintf ( 'the amount to be sent after %d hour is : %d \n ', i ,x(i) );
end