% ----CO-TECH problem ------%
% --- decision variables --- %
% --xi = the salary of person A, 1 for A , 2 for B...
% --- xa >= 20,000 lower bound of x1
% --- xb - xa >= 5000 
% --- xc - xa >= 5000
% --- xd - xa >= 5000
% --- xe >= xa + xb 
% --- xf >= 200 + xe
% --- xc + xd >= 2(xa + xb)
%---- xg >= xb
% --- xg >= xd
% --- xg + xb >= 60,000
% --- xf <= xg + xa

% -------------------------------------------------%


sal = [1;1;1;1;1;1;1];
a = [1 ,-1 , 0 , 0 , 0 , 0 , 0 ;
     1 , 0 ,-1 , 0 , 0 , 0 , 0 ;
     1 , 0 , 0 , -1 , 0 , 0 , 0 ;
     1 , 1 , 0 , 0 , -1 , 0, 0;
     2 , 2 , -1 ,-1, 0 , 0 , 0 ;
     0 , 1 , 0 , 0 , 0 , 0 , -1;
     0 , 0 , 0 , 1 , 0 , 0 ,-1;
     0 , -1 , 0 , 0 , 0 , 0 , -1;
     -1 , 0 , 0 , 0 , 0 , 1 , -1 ] ;
 b = [ -5000 ; -5000 ; -5000 ; 0 ; 0 ; 0 ; 0 ; -60000 ; 0 ];
 
 aeq = [ 0 , 0 , 0  , 0 , 1 , -1 , 0 ];
 beq = [ -200 ];
 lb = [20000 ; 0 ; 0 ; 0 ; 0 ; 0 ; 0 ];
 [x,fval] = linprog(sal,a , b , aeq , beq , lb);
 
 fprintf(' Total salary expense is : %d \n',  fval);
for i=1:7
    fprintf(' salary of person % d is : %d \n', i, x(i));
end
     
