%  ----- AMUL PROBLEM -------- %
% -- decision variables --- %
% xi = volume of product i , 1 = skimmed milk, 2 = 2% , 3= whole milk
%  VOLUME CONSTRAINT
%  x1 +x2 +x3 +x4 +x5 <=7500 
% FAT constraint 
% 0*x1 +0.02*x2 +0.04*x3 + 0.15*x4 +0.45x5 <= 0.037*5000+0.049*2500
% ----------------------------------------------%

prof = [-5;-7.5;-10;-85;-400];
a = [1,1,1,1,1; 0,0.02,0.04,0.15,0.45];
b = [7500 ; 307.5];

lb = [0;0;0;0;0];
[x,fval] = linprog(prof,a,b,[],[],lb,[]);

fprintf(' Total profit is : %d \n',  fval);
for i=1:5
    fprintf(' volume of item % d is : %d \n', i, x(i));
end