prof = [-5;-7.5;-10;-85;-400];
a = [1,1,1,1,1; 0.1,0.02,0.04,0.15,0.45];
b = [7500 ; 307.5];

lb = [0;0;0;0;0];
[x,fval] = linprog(prof,a,b,[],[],lb);

fprintf(' Total profit is : %d \n',  fval);
for i=1:5
    fprintf(' volume of item % d is : %d \n', i, x(i));
end